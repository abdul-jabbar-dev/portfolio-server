
// import { ProjectSchema } from "../../projects.schema";

// ProjectSchema.pre('save', function addDate(next) {
//     console.log("this.name")
// })