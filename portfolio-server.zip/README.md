﻿﻿# Welcome to [ D-COM.co](https://d-com-aj.web.app/)


[Live hosting](https://d-com-aj.web.app/)

[Client side code link](https://github.com/abduljabbar15/as-12-d-com-client)

[server side code link](https://github.com/abduljabbar15/as-12-d-com-server)

 - A graphic Market
 - Responsive Navigation Menu and React Router 4.
 - Fully responsive layout and well optimized.
 - Use Material-UI
 - public Admin=> admin@admin.com pass=> 123456



